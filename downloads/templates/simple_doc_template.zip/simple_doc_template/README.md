# Simple Document Template

Minimal LaTeX template for reports and assignments with styled title and bibliography support.

## Structure

```
simple-doc-template/
├── template.tex      # Main document
└── biblio.bib        # Bibliography (optional)
```

## Quick Start

```bash
# 1. Edit template.tex (title, author, content)
# 2. Compile
pdflatex template.tex

# With bibliography:
pdflatex template.tex && bibtex template && pdflatex template.tex && pdflatex template.tex
```

## Usage

```latex
\title{ 
    \textsc{Course Name}\\
    {\huge Document Title}\\
}
\author{Your Name}

\begin{document}
\maketitle

\subsection*{Section}
Content here. Citations: \cite{key}

% Optional figure:
% \begin{figure}[H]
%     \includegraphics[scale=0.7]{image.png}
%     \caption{Description}
% \end{figure}

\bibliography{biblio}
\bibliographystyle{ieeetr}
\end{document}
```

## Features

| Feature | Usage |
|---------|-------|
| Styled title | Centered, ruled, small caps |
| Math notation | `\ket{\psi}`, `\bra{\phi}` |
| Figure placement | `\begin{figure}[H]` for exact position |
| Citations | `\cite{key}` (IEEE style) |
| Code blocks | `\begin{lstlisting}[language=Python]` |

## Bibliography

Create `biblio.bib`:
```bibtex
@article{key,
    author = "Author Name",
    title = "Paper Title",
    year = "2024"
}
```

**Disable bibliography:** Comment out lines:
```latex
% \bibliography{biblio}
% \bibliographystyle{ieeetr}
```

## Customization

**Margins:**
```latex
\geometry{top=2cm, bottom=2cm, left=3cm, right=3cm}
```

**Font:**
```latex
\usepackage{fourier}  % Current
% \usepackage{lmodern} % Alternative
```

**Section style:**
```latex
\sectionfont{\centering\scshape}  % Centered, small caps
```

---

**Simple. Fast. Done.** 📄
# LaTeX Notes Template

Clean, modular template for lecture notes.

## Structure

```
notes-template/
├── main.tex          # Main document
├── preamble.tex      # Packages & settings
└── sections/
    ├── m1.tex
    └── m2.tex
```

## Quick Start

```bash
# 1. Edit main.tex (author, title, date)
# 2. Create section files in sections/
# 3. Compile
pdflatex main.tex
```

## Usage

**Main document:**
```latex
\documentclass[a4paper,12pt]{article}
\input{preamble.tex}

\author{Your Name}
\title{Notes Title}
\date{2025-12-03}

\begin{document}
\maketitle
\tableofcontents
\newpage

\import{sections/}{m1}
\end{document}
```

**Section file** (`sections/m1.tex`):
```latex
\section{Topic}
Content here.
```

## Features

| Feature | Usage |
|---------|-------|
| Math notation | `\ket{\psi}` → \|ψ⟩, `\bra{\phi}` → ⟨φ\| |
| Highlight | `\hl{text}` |
| Blue notes | `\textit{\textcolor{blue}{note}}` |
| Exact figure position | `\begin{figure}[H]` |
| Code blocks | `\begin{lstlisting}[language=Python]` |

## Customization

**Margins** (`preamble.tex`):
```latex
\usepackage[margin=2cm]{geometry}
```

**Font** (`preamble.tex`):
```latex
\usepackage{fourier}  % Options: lmodern, palatino, times
```

**TOC depth** (`main.tex`):
```latex
\setcounter{tocdepth}{2}  % 0=none, 1=sections, 2=subsections
```

## Add Bibliography

```latex
% In main.tex
\bibliographystyle{plain}
\bibliography{references}

% Compile:
pdflatex main.tex && bibtex main && pdflatex main.tex && pdflatex main.tex
```

## Troubleshooting

- **File not found**: Check paths relative to `main.tex`
- **Images missing**: Verify file extension (`.png`, `.jpg`, `.pdf`)
- **Slow compile**: Delete `*.aux`, `*.log`, `*.out` files

## Packages

Math, graphics, tables, code, hyperlinks, citations. See `preamble.tex` for full list.

---

**Done. Start writing.** 📚